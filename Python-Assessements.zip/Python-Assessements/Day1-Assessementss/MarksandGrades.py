marks=float(input("Enter the mark"))
if(marks>=0 and marks<=100):
    print("Valid marks")
else:
    print("Invalid marks")
if(marks>=0 and marks<=39):
    print("Fail")
elif(marks>=40 and marks<=59):
    print("Third class")
elif(marks>=60 and marks<=79):
    print("Second class")
elif(marks>=80 and marks<=100):
    print("First class")
    
    
