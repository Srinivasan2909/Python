num=int(input("Enter the number"))
for i in range(0,num+1):
    print(" "*(num-i)," *"*i)
